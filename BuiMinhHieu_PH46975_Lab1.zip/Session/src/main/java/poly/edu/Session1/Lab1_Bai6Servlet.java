package poly.edu.Session1;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;

@WebServlet(name = "Lab1_Bai6Servlet", value = "/Lab1_Bai6Servlet")
public class Lab1_Bai6Servlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/param/form_rectangle.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        double rong = Double.parseDouble(request.getParameter("rong"));
        double dai = Double.parseDouble(request.getParameter("dai"));
        double chuVi = (dai + rong) * 2;
        double dienTich = dai * rong;

        request.setAttribute("chuVi", chuVi);
        request.setAttribute("dienTich", dienTich);

        request.getRequestDispatcher("/param/result_rectangle.jsp").forward(request, response);
    }
}
