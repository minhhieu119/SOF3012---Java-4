package poly.edu.Session1;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;

@WebServlet(name = "Lab1_Bai5Servlet", value = "/Lab1_Bai5Servlet")
public class Lab1_Bai5Servlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/param/form.jsp").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String hoTen = request.getParameter("hoTen");
        request.setAttribute("message", "Xin chào " + hoTen);
        request.getRequestDispatcher("/param/success.jsp").forward(request, response);
    }
}
